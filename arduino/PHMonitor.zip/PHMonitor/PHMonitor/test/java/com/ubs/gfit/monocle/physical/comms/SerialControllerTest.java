package com.ubs.gfit.monocle.physical.comms;

import java.util.ArrayList;

import com.ubs.gfit.monocle.physical.comms.CommsController;
import com.ubs.gfit.monocle.physical.comms.SerialController;

import junit.framework.TestCase;

public class SerialControllerTest extends TestCase
{

    protected void setUp() throws Exception
    {
        super.setUp();
    }

    protected void tearDown() throws Exception
    {
        super.tearDown();
    }

    public void testSerialController()
    {
        CommsController s = new SerialController("C:\\dev\\projects\\uController\\PHMonitor\\lib");
        ArrayList<String> al = s.getPortList();
        
        for(int i=0;i<s.getPortList().size();i++)
        {
            System.out.println("Port:"+al.get(i));
        }
    }

}
