package com.ubs.gfit.monocle.physical.comms;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.TooManyListenersException;
import javax.swing.AbstractAction;
import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gnu.io.UnsupportedCommOperationException;
import java.awt.event.ActionEvent;

public class IOTesting extends JFrame implements SerialPortEventListener
{
    private static final long serialVersionUID = -1300018973842188891L;
    static InputStream in;
    private JButton sendButton;
    static JTextField inputTextField;
    private AbstractAction sendAction;
    private JTextArea outputTextArea;
    private JScrollPane scrollPane;
    static OutputStream out;

    private Object prependToJavaLibraryPath(String newPath) throws NoSuchFieldException, IllegalAccessException
    {
        String currentPath = System.getProperty("java.library.path");

        // Reset the "sys_paths" field of the ClassLoader to null.
        Class<ClassLoader> clazz = ClassLoader.class;
        Field field = null;
        boolean accessible=false;
        Object original=null;

        try
        {
            field = clazz.getDeclaredField("sys_paths");

            accessible = field.isAccessible();
            if (!accessible)
                field.setAccessible(true);

            original = field.get(clazz);

            // Reset field to null causes the sys_path to be rebuilt when a call is made to
            // System.loadLibrary.
            field.set(clazz, null);

            // Pre-pend the new path to the java.library.path
            System.setProperty("java.library.path", newPath+File.pathSeparator+currentPath);
        }
        finally 
        {
            // Revert back the field accessibility.
            field.setAccessible(accessible);
        }

        return original;
    }

    public void connect(String identifier)
    {
        CommPortIdentifier portIdentifier;

        try
        {
            portIdentifier = CommPortIdentifier.getPortIdentifier(identifier);

            if (portIdentifier.isCurrentlyOwned())
            {
                System.out.println("Error: Port is currently in use");
            }
            else
            {
                CommPort commPort = portIdentifier.open("IOTesting", 2000);

                if (commPort instanceof SerialPort)
                {
                    SerialPort serialPort = (SerialPort) commPort;
                    serialPort.setSerialPortParams(57600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1,
                            SerialPort.PARITY_NONE);

                    serialPort.addEventListener(this);
                    serialPort.notifyOnDataAvailable(true);

                    in = serialPort.getInputStream();
                    out = serialPort.getOutputStream();
                }
                else
                {
                    System.out.println("Error: Only serial ports are handled by this example.");
                }
            }
            this.setTitle("Conencted to:"+identifier);

        }
        catch (NoSuchPortException e)
        {
            e.printStackTrace();
        }
        catch (PortInUseException e)
        {
            e.printStackTrace();
        }
        catch (UnsupportedCommOperationException e)
        {
            e.printStackTrace();
        }
        catch (TooManyListenersException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }



    public void initGUI()
    {
        getContentPane().setLayout(null);
        {
            sendButton = new JButton();
            getContentPane().add(sendButton);
            sendButton.setText("jButton1");
            sendButton.setAction(getAbstractAction());
            sendButton.setBounds(171, 12, 89, 20);
            getContentPane().add(getJTextField1());
            getContentPane().add(getScrollPane());
        }
        this.setSize(279, 231);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args)
    {
        IOTesting r = new IOTesting();
        try
        {
            r.prependToJavaLibraryPath(System.getProperty("user.dir") + "/lib");
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.exit(0);
        }
        r.initGUI();

        if(args.length>0)
            r.connect(args[0]);

    }

    public void serialEvent(SerialPortEvent event)
    {
        switch (event.getEventType())
        {

        case SerialPortEvent.BI:
        case SerialPortEvent.OE:
        case SerialPortEvent.FE:
        case SerialPortEvent.PE:
        case SerialPortEvent.CD:
        case SerialPortEvent.CTS:
        case SerialPortEvent.DSR:
        case SerialPortEvent.RI:
        case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
            break;

        case SerialPortEvent.DATA_AVAILABLE:
            byte[] readBuffer = new byte[2048];

            try
            {
                while (in.available() > 0)
                {
                    int numBytes = in.read(readBuffer);
                    System.out.println("Read ["+numBytes+"]");
                }

                this.outputTextArea.append(new String(readBuffer)+"\n");
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

            break;
        }

    }

    private AbstractAction getAbstractAction()
    {
        if (sendAction == null)
        {
            sendAction = new AbstractAction("Send", null)
            {
                private static final long serialVersionUID = -1620461784757753269L;

                public void actionPerformed(ActionEvent evt)
                {
                    byte[] b = IOTesting.inputTextField.getText().getBytes();
                    try
                    {
                        IOTesting.out.write(b);
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                    IOTesting.inputTextField.setText("");
                }
            };
        }
        return sendAction;
    }

    private JTextField getJTextField1()
    {
        if (inputTextField == null)
        {
            inputTextField = new JTextField();
            inputTextField.setBounds(17, 12, 142, 20);
        }
        return inputTextField;
    }

    private JScrollPane getScrollPane()
    {
        if (scrollPane == null)
        {
            scrollPane = new JScrollPane();

            outputTextArea = new JTextArea();
            scrollPane.setViewportView(outputTextArea);
            scrollPane.setBounds(13, 56, 244, 134);
            outputTextArea.setBounds(13, 56, 244, 134);
            outputTextArea.setEditable(false);

        }
        return scrollPane;
    }

}
