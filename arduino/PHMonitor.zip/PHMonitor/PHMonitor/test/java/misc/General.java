package misc;

import java.awt.GraphicsEnvironment;
import java.util.Enumeration;
import java.util.Properties;

import junit.framework.TestCase;

@SuppressWarnings("unchecked")
public class General extends TestCase
{

    protected void setUp() throws Exception
    {
    }

    protected void tearDown() throws Exception
    {
    }
    
    public void testDumpSystemProperties()
    {
        Properties prop = System.getProperties();
        
        Enumeration keys = prop.keys();
        while(keys.hasMoreElements())
        {
            String key = (String)keys.nextElement();
            System.out.println("k=["+key+"] v=["+prop.getProperty(key)+"]");
        }
    }
    
    public void testGetFontFamilyNames()
    {
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fonts = ge.getAvailableFontFamilyNames();
        for(int i=0;i<fonts.length;i++)
        {
            System.out.println("Font family:"+fonts[i]);
        }
    }

}
