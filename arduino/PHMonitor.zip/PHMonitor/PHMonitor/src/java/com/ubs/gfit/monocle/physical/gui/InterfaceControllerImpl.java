package com.ubs.gfit.monocle.physical.gui;

import java.awt.AWTException;
import java.awt.CheckboxMenuItem;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.net.URI;
import java.util.Iterator;
import java.awt.Desktop;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.apache.log4j.Logger;

import com.ubs.gfit.monocle.physical.PropertiesController;
import com.ubs.gfit.monocle.physical.Utilities;
import com.ubs.gfit.monocle.physical.comms.CommsController;
import com.ubs.gfit.monocle.physical.comms.CommsControllerCallback;
import com.ubs.gfit.monocle.physical.comms.SerialController.Command;
import com.ubs.gfit.monocle.physical.interragator.Interrogator;
import com.ubs.gfit.monocle.physical.interragator.Interrogator.RagStatus;
import com.ubs.gfit.monocle.physical.interragator.InterrogatorThread;

public class InterfaceControllerImpl implements InterfaceController, CommsControllerCallback
{
    Logger logger = Logger.getLogger(InterfaceControllerImpl.class);
    private PopupMenu popup;
    private TrayIcon trayIcon;
    private SystemTray systemTray;
    private ImageUtilities imgUtils = null;
    private CommsController controller = null;;
    private Interrogator interrogator = null;
    private Thread poller = null;
    private PropertiesController propertiesController=null;
    
    public InterfaceControllerImpl(CommsController controller)
    {
        this.controller = controller;
        this.controller.registerCallback(this);
        this.propertiesController = new PropertiesController("/monocle-config.xml");
    }
    
    public void initUIManager()
    {
        imgUtils = new ImageUtilities(controller);
        /* Use an appropriate Look and Feel */
        try
        {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        }
        catch (UnsupportedLookAndFeelException e)
        {
            logger.error("Exception:"+Utilities.generateStackTrace(e));
        }
        catch (IllegalAccessException e)
        {
            logger.error("Exception:"+Utilities.generateStackTrace(e));
        }
        catch (InstantiationException e)
        {
            logger.error("Exception:"+Utilities.generateStackTrace(e));
        }
        catch (ClassNotFoundException e)
        {
            logger.error("Exception:"+Utilities.generateStackTrace(e));
        }

        /* Turn off metal's use of bold fonts */
        UIManager.put("swing.boldMetal", Boolean.FALSE);
    }
    
    private Menu buildPortsSubMenu()
    {
        Menu comPorts = new Menu("Port");
        // build the item listener for the ports sub-menu
        // note it is an item listener as we are using checkboxes
        ItemListener itemListener = new ItemListener()
        {
            public void itemStateChanged(ItemEvent e)
            {
                CheckboxMenuItem item = (CheckboxMenuItem)e.getSource();
                controller.setPort(item.getLabel());
                item.setState(true);
                logger.debug("Action event on comPorts: source="+item.getLabel());
                Menu p = (Menu) item.getParent();
                for(int i=0;i<p.getItemCount();i++)
                {
                    CheckboxMenuItem o = (CheckboxMenuItem)p.getItem(i);
                    if(o.getLabel().compareToIgnoreCase(item.getLabel())!=0)
                    {
                        o.setState(false);
                        o.setEnabled(!controller.isPortInUse(o.getLabel()));
                    }
                }
                // if we have selected a port we can make the Connect option enabled
                Menu mainMenu = (Menu)p.getParent();
                for(int i=0;i<mainMenu.getItemCount();i++)
                {
                    MenuItem mainItem = mainMenu.getItem(i);
                    if(mainItem.getLabel().compareToIgnoreCase("Connect")==0)
                    {
                        mainItem.setEnabled(true);
                    }
                }
            }
        };
        
        // Now build the sub-menu and apply the listener we have just created
        Iterator<String> i = (controller.getPortList()).iterator();        
        while(i.hasNext())
        {
            String port = i.next();

            CheckboxMenuItem mi = new CheckboxMenuItem(port);
            mi.addItemListener(itemListener);
            if(controller.getPort()!=null && port.equals(controller.getPort()))
            {
                mi.setState(true);
            }
            else
            {
                mi.setState(false);
            }
            mi.setEnabled(!controller.isPortInUse(port));
            comPorts.add(mi);               
        }
        
        return comPorts;
    }
    
    public void createAndShowGUI()
    {
        // Check the SystemTray support
        if (!SystemTray.isSupported())
        {
            System.out.println("SystemTray is not supported");
            return;
        }
        
        popup = new PopupMenu();
        trayIcon = new TrayIcon(imgUtils.applyConnectedStatusToImage("images/off.png"));
        trayIcon.setToolTip("Monocle Physical Monitor");
        trayIcon.setImageAutoSize(true);
        systemTray = SystemTray.getSystemTray();

        // Create a popup menu components
        MenuItem aboutItem = new MenuItem("About");
        

        
        MenuItem connect = new MenuItem("Connect");
        if(controller.getPort()==null)
        {
            connect.setEnabled(false);
        }
        
 

        MenuItem exitItem = new MenuItem("Exit");

        // Add components to popup menu
        popup.add(aboutItem);
        popup.addSeparator();
        popup.add(connect);
        popup.add(buildPortsSubMenu());
        popup.addSeparator();
        popup.add(exitItem);
        
        trayIcon.setPopupMenu(popup);

        try
        {
            systemTray.add(trayIcon);
        }
        catch (AWTException e)
        {
            System.out.println("TrayIcon could not be added.");
            return;
        }

        trayIcon.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
            	if( !Desktop.isDesktopSupported() ) 
            	{
            		logger.error("Desktop is not supported(fatal)");
            		System.exit(-1);
            	}
            	
            	Desktop desktop = Desktop.getDesktop();

            	if( !desktop.isSupported( java.awt.Desktop.Action.BROWSE ) ) 
            	{

    	            logger.error( "Desktop doesn't support the browse action (fatal)" );
    	            System.exit(-1);
            	}

            	try
            	{
	                URI uri = new URI((String)propertiesController.getPropertyForKey("monocle_url"));
	                desktop.browse( uri );
            	}
            	catch ( Exception ex )
            	{

            	                System.err.println( ex.getMessage() );
            	}
            }
        });
        

        connect.addActionListener(new ActionListener()
        {
            public void enablePortsMenu(Menu menu)
            {
                for(int i=0;i<menu.getItemCount();i++)
                {
                    CheckboxMenuItem mi = (CheckboxMenuItem)menu.getItem(i);
                    mi.setEnabled(!controller.isPortInUse(mi.getLabel()));
                    
                    if(controller.getPort()!=null && mi.getLabel().equals(controller.getPort()))
                    {
                        mi.setState(true);
                    }
                    else
                    {
                        mi.setState(false);
                    }
                }
            }
            
            public void disablePortsMenu(Menu menu)
            {
                for(int i=0;i<menu.getItemCount();i++)
                {
                    ((CheckboxMenuItem)menu.getItem(i)).setEnabled(false);
                }
            }
           public void actionPerformed(ActionEvent e)
           {
               //toggle connect, disconnect
               MenuItem item = (MenuItem)e.getSource();
               
               
               if(item.getLabel().compareTo("Connect")==0)
               {
                   //we got a connection request
                   logger.debug("Attempting connect");
                   controller.connect();
                   if(controller.connected())
                   {
                       item.setLabel("Disconnect");
                       passToCommsController(interrogator.getCurrentStatus());
                       //disable all the entries in the ports sub-menu
                       Menu m = (Menu)item.getParent();
                       for(int i=0;i<m.getItemCount();i++)
                       {
                           MenuItem mi = (MenuItem)m.getItem(i);
                           //logger.debug("mi"+mi.getLabel());
                           if(mi.getLabel().equals("Port"))
                           {
                               disablePortsMenu((Menu)mi);
                           }
                       }                       
                   }
                   else
                   {
                       logger.debug("Controller not connected so provide feedback.");
                       JOptionPane.showMessageDialog(null, "Failed to connect, check port.");
                   }
               }
               else
               {
                   //we got a disconnection request
                   logger.debug("Attempting disconnect");
                   controller.disconnect();
                   
                   item.setLabel("Connect");
                   
                   Menu m = (Menu)item.getParent();
                   for(int i=0;i<m.getItemCount();i++)
                   {
                       MenuItem mi = (MenuItem)m.getItem(i);
                       if(mi.getLabel().equals("Port"))
                       {
                           enablePortsMenu((Menu)mi);
                       }
                   }
                   passToCommsController(interrogator.getCurrentStatus());
               }
           }
        });
        
        aboutItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {

                AboutDialog inst = new AboutDialog(null);
                inst.setLocationRelativeTo(null);;
                inst.setVisible(true);
            }
        });

        exitItem.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                systemTray.remove(trayIcon);
                System.exit(0);
            }
        });
    }

    public void setController(CommsController controller)
    {
        this.controller = controller;
        
    }
    
    public void setInterrogator(Interrogator interrogator)
    {
        this.interrogator = interrogator;
    }
    
    public void startInterrogator()
    {
        if(poller!=null)
        {
            //we have an active poller so we should kill it before creating a new thread
            poller.interrupt();
            poller = null;
        }
        int delay = new Integer((String)propertiesController.getPropertyForKey("delay")).intValue();
        poller = new Thread(new InterrogatorThread(this, interrogator, delay));
        poller.start();
    }
    
    public void update(RagStatus status)
    {
    	if(status!=null)
    	{
	        switch(status)
	        {
	            case RED:
	                trayIcon.setImage(imgUtils.applyConnectedStatusToImage("images/smallRedCircle.png"));
	                break;
	            case AMBER:
	                trayIcon.setImage(imgUtils.applyConnectedStatusToImage("images/smallAmberCircle.png"));
	                break;
	            case GREEN:
	                trayIcon.setImage(imgUtils.applyConnectedStatusToImage("images/smallGreenCircle.png"));
	                break;
	            case UNKNOWN:
            	default:
	            	trayIcon.setImage(imgUtils.applyConnectedStatusToImage("images/off.png"));
	        }
    	}

    	if(controller.connected())
    	{
    		passToCommsController(status);
    	}
    }
    
    private void passToCommsController(RagStatus status)
    {
    	logger.debug("Passing status:"+status+" to comms controller");
		controller.setStatus(status);
    }
    
//    public boolean getRunState()
//    {
//        return true;
//    }

    public void commsEvent(Command command)
    {
        logger.debug("Processing command:"+command);
        /*switch(command)
        {
            case BTTN:
                logger.debug("Got button press from device");
                break;
            default:
                logger.warn("Got unknown command:"+command+" don't know how to process");
        }*/
        
    }
}
