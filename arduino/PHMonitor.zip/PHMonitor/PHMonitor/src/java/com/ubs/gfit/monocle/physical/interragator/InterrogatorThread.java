package com.ubs.gfit.monocle.physical.interragator;

import org.apache.log4j.Logger;

import com.ubs.gfit.monocle.physical.gui.InterfaceController;
import com.ubs.gfit.monocle.physical.interragator.Interrogator.RagStatus;

public class InterrogatorThread implements Runnable
{
    private static InterfaceController uiController = null;
    private static Interrogator interrogator = null;
    private boolean running = true;
    private Logger logger = Logger.getLogger(InterrogatorThread.class);
    private static int delay=0;
    
    public InterrogatorThread(InterfaceController uiController, Interrogator interrogator, int delay)
    {
        InterrogatorThread.uiController = uiController;
        InterrogatorThread.interrogator = (Interrogator) interrogator;
        InterrogatorThread.delay = delay;
    }
    
    public void run()
    {
        try
        {
            while(running)
            {
            	RagStatus status = interrogator.getCurrentStatus();
            	logger.debug("Interrogator returned:"+status);
            	uiController.update(status);
            	
                logger.debug("Sleeping");
                Thread.sleep(delay);
            }
                
        }
        catch (InterruptedException e)
        {}
    }
}
