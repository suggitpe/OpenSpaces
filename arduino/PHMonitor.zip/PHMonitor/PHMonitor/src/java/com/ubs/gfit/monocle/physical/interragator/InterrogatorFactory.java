package com.ubs.gfit.monocle.physical.interragator;

import java.lang.reflect.InvocationTargetException;

import org.apache.log4j.Logger;

import com.ubs.gfit.monocle.physical.PropertiesController;

public class InterrogatorFactory {
	private static Logger logger = Logger.getLogger(InterrogatorFactory.class);

	public static Interrogator getInterrogator() {
		PropertiesController propertiesController = new PropertiesController(
				"/monocle-config.xml");
		String className = (String) propertiesController
				.getPropertyForKey("interrogator");

		logger.debug("Attempting to create class:"+className);
		try {
			Class<?>[] classParameters = null;
			Object[] constructorParameters = null;
			Class<?> classz = Class.forName(className);
			java.lang.reflect.Constructor<?> co = classz
					.getConstructor(classParameters);
			return (Interrogator) co.newInstance(constructorParameters);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
