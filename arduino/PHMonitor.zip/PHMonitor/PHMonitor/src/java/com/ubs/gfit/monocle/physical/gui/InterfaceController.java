package com.ubs.gfit.monocle.physical.gui;

import com.ubs.gfit.monocle.physical.comms.CommsController;
import com.ubs.gfit.monocle.physical.interragator.Interrogator;
import com.ubs.gfit.monocle.physical.interragator.Interrogator.RagStatus;

public interface InterfaceController
{

    public abstract void initUIManager();

    public abstract void createAndShowGUI();

    public abstract void setController(CommsController controller);

    public abstract void setInterrogator(Interrogator interrogator);

    public abstract void startInterrogator();

    public abstract void update(RagStatus status);

}