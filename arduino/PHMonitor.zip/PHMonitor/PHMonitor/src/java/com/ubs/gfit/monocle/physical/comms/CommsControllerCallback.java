package com.ubs.gfit.monocle.physical.comms;

import com.ubs.gfit.monocle.physical.comms.SerialController.Command;

public interface CommsControllerCallback
{
    public void commsEvent(Command command);
}
