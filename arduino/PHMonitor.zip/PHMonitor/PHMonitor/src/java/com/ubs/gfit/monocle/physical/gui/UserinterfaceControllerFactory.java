package com.ubs.gfit.monocle.physical.gui;

import com.ubs.gfit.monocle.physical.comms.CommsController;

public class UserinterfaceControllerFactory
{

    public static InterfaceController getInterfaceController(CommsController controller)
    {
        // TODO Auto-generated method stub
        return new InterfaceControllerImpl(controller);
    }

}
