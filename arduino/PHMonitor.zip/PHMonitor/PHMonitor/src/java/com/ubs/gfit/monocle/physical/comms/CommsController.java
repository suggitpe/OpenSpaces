package com.ubs.gfit.monocle.physical.comms;

import java.util.ArrayList;

import com.ubs.gfit.monocle.physical.interragator.Interrogator.RagStatus;

public interface CommsController
{
    public boolean connect();
    
    public void disconnect();
    
    public ArrayList<String> getPortList();

    public boolean connected();

    public boolean isPortInUse(String port);
    
    public String getPort();
    
    public boolean setPort(String port);

    // need to fix these two as they don't belong in a general interface
    public void setStatus(RagStatus state);
    
    public void registerCallback(CommsControllerCallback callback);


}
