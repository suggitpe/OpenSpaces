package com.ubs.gfit.monocle.physical.comms;

import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gnu.io.UnsupportedCommOperationException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.ListIterator;
import java.util.TooManyListenersException;

import org.apache.log4j.Logger;

import com.ubs.gfit.monocle.physical.Utilities;
import com.ubs.gfit.monocle.physical.interragator.Interrogator.RagStatus;

/**
 * SerialController is an implementation of the CommsController interface and provides
 * a means of communicating with a serial port. In addition this class implements the 
 * SerialPortEventListener interface which means it can be used as the callback from
 * serial events.
 * @author clokema
 *
 */
public class SerialController implements CommsController, SerialPortEventListener
{
    Logger logger = Logger.getLogger(SerialController.class);
    private boolean connected = false;
    private String port = null;
    private SerialPort serialPort = null;
    private static OutputStream out=null;
    private static InputStream in = null;
    private ArrayList<CommsControllerCallback> callbackList;

    /**
     * Create a SerialController with the library path searched 
     * for the rxtx shared libraries being set to the current working 
     * directory by the user.dir System property.
     */
    public SerialController()
    {
        new SerialController(System.getProperty("user.dir"));
    }
    
    /**
     * Create a SerialController with the library path searched for the rxtx shared libraries
     * being set to librarypath.
     * @param libraryPath String path to pre-pend to the java.library.path
     */
    public SerialController(String libraryPath)
    {
        try
        {
            Utilities.prependToJavaLibraryPath(libraryPath);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw new RuntimeException("Unable to create SerialController as prepending to java.library.path failed.");
        }
        callbackList = new ArrayList<CommsControllerCallback>();
    }
    
    /**
     * Register CommsControllerCallback objects to be informed when an
     * event has occurred that they would be interested in.
     * @param callback An object implementing the CommsControllerCallback interface.
     */
    public void registerCallback(CommsControllerCallback callback)
    {
        callbackList.add(callback);
    }

    /**
     * This method provides a means of discovering what serial ports
     * the machine had. This method, does not determine whether the serial
     * port is available for use.
     * @return ArrayList<String> of discovered SerialPorts.
     */
    @SuppressWarnings("unchecked")
    public ArrayList<String> getPortList()
    {
        ArrayList<String> list = new ArrayList<String>();
        Enumeration<CommPortIdentifier> portList = CommPortIdentifier.getPortIdentifiers();
        
        while (portList.hasMoreElements())
        {
            CommPortIdentifier portId = portList.nextElement();
            if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL)
            {
                list.add(portId.getName());
                logger.debug("Got serial port: ["+portId.getName()+"]");
            }
        }
        return list;
    }

    /**
     * This method provides a means of determining whether the SerialController is connected
     * to a port.
     * @return boolean indicating the connection status of this SerialController.
     */
    public boolean connected()
    {
        if(this.connected)
            return true;
        else
            return false;
    }
    
    /**
     * This method provides the means of setting which port the SerialController should connect to.
     * Before setting the port to the specified value, a check is made to determine that no open
     * connection is currently open. If a connection is open then false is returned, otherwise true
     * is returned.
     * @param port String representing the port that this SerialController should connect to.
     * @return boolean indicating the success or failure of the method to set the port to the new value.
     */
    public boolean setPort(String port)
    {
        if(connected)
            return false;
        this.port = port;
        return true;
    }
    
    /**
     * This method provides a means of getting the port for this controller.
     * @return String representing the port this SerialController will use.
     */
    public String getPort()
    {
        return port;
    }
    
    /**
     * Given a String identifying a port, this method will determine whether it is in use.
     * This is a test against the underlying OS and not just within the context of this code.
     * @param port String representing a port to check. 
     */
    public boolean isPortInUse(String port)
    {
        SerialPort p = null;
        boolean result = false;
        try
        {
            //logger.debug("Checking whether port:["+port+"] is available");
            CommPortIdentifier portId = CommPortIdentifier.getPortIdentifier(port);
            p = (SerialPort) portId.open("Test",10);
            //logger.debug("connected without failure so port is not in use");
            result = false;
        }
        catch(NoSuchPortException e)
        {
            result = true;
        }
        catch(PortInUseException e)
        {
            result = true;
        }
        finally
        {
            try
            {
                p.close();
            }
            catch(Exception e)
            {}
        }
        return result;
    }

    /**
     * This method connects the SerialController to a serial port at 57600 baud, with 8
     * databits, 1 stopbit and no parity. The call will fail if the port object has not been
     * set for this serial controller.
     * @return boolean indicating whether connection attempt has succeeded.
     */
    public boolean connect()
    {
        if(port==null)
            return false;
        //1. Create a SerialPort object
        try 
        {
            CommPortIdentifier portId = CommPortIdentifier.getPortIdentifier(port);
            serialPort = (SerialPort) portId.open("PHMonitor", 500);
            serialPort.setSerialPortParams(57600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1,
                    SerialPort.PARITY_NONE);
            
            serialPort.addEventListener(this);
            serialPort.notifyOnDataAvailable(true);
            
            out = serialPort.getOutputStream();
            in = serialPort.getInputStream();
            connected=true;
        }
        catch(NoSuchPortException e)
        {
            logger.error("Attempt to connect to unknown port:["+port+"]");
            logger.error(Utilities.generateStackTrace(e));
            return false;
        }
        catch(PortInUseException e)
        {
            logger.error("Port:["+port+"] already in use.");
            logger.error(Utilities.generateStackTrace(e));
            return false;
        }
        catch (IOException e)
        {
            logger.error(Utilities.generateStackTrace(e));
            return false;
        }
        catch (TooManyListenersException e)
        {
            logger.error(Utilities.generateStackTrace(e));
            return false;
        }
        catch (UnsupportedCommOperationException e)
        {
            logger.error(Utilities.generateStackTrace(e));
            return false;
        }
        return true;

    }
    
    /**
     * This method disconnects the SerialController. If the controller is not connected
     * this call has no effect.
     */
    public void disconnect()
    {
        if(!connected)
            return;
        serialPort.close();
        connected = false;
    }

    public void setStatus(RagStatus status)
    {
    	switch(status)
    	{
    		case RED:
    			sendCommand("STATE:Red.");
    			break;
    		case GREEN:
    			sendCommand("STATE:Green.");
    			break;
    		case AMBER:
    			sendCommand("STATE:Amber.");
    			break;
    		default:
    			sendCommand("STATE:"+status+".");
    	}
    }
    
    /**
     * Sends the specified string to the currently connected serial port.
     * @param toSend String that will be sent to the serial port.
     */
    public void sendCommand(String toSend)
    {
        if(port==null || out==null)
            return;
        
        logger.debug("Sending :["+toSend+"] to port:["+port+"]");
        
        byte[] b = toSend.toString().getBytes();
        try
        {
            out.write(b);
        }
        catch (IOException e)
        {
            logger.error(Utilities.generateStackTrace(e));
        }        
    }
    
    /**
     * Command Enumeration represents all the commands that can be
     * returned by the remote device. 
     * 
     * @author clokema
     */
    public enum Command
    {
        BTTN, UNKNOWN;

        /** 
         * Static method that given a String returns the corresponding
         * Command type.
         * @param com String representing a command that we want the type for
         * @return Command type, UNKNOWN if attempt to determine type failed or
         * was not recognised.
         */
        public static Command getCommandForString(String com)
        {
            if(com.equals("BTTN."))
                return Command.BTTN;
            return Command.UNKNOWN;
        }
    }
    
    /**
     * This method iterates through the list of all objects registered to receive
     * CommsControllerCallback notifications.
     * @param command Command indicating what occurred. (@see Command)
     */
    private void notifyAll(Command command)
    {
        for (ListIterator<CommsControllerCallback> it = callbackList.listIterator(); it.hasNext(); )
        {
            CommsControllerCallback callback = it.next();
            callback.commsEvent(command);
        }
    }
    

    /**
     * Implementation of the SerialPortEventListener interface. This method is called
     * when new data is available on the serial port.
     * 
     * @param event SerialPortEvent indicating why this interface has been invoked.
     */
    public void serialEvent(SerialPortEvent event)
    {
        switch (event.getEventType())
        {
            case SerialPortEvent.BI:
            case SerialPortEvent.OE:
            case SerialPortEvent.FE:
            case SerialPortEvent.PE:
            case SerialPortEvent.CD:
            case SerialPortEvent.CTS:
            case SerialPortEvent.DSR:
            case SerialPortEvent.RI:
                
            case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
                break;
    
            case SerialPortEvent.DATA_AVAILABLE:
                byte[] readBuffer = new byte[2048];
    
                try
                {
                    while (in.available() > 0)
                    {
                        int numBytes = in.read(readBuffer);
                        System.out.println("Read ["+numBytes+"]");
                    }
                    // here we need to notify the GUI of the message we have received
                    String received = new String(readBuffer);
                    received = received.trim();
                    logger.debug("received:"+received);
                    notifyAll(Command.getCommandForString(received));
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
    
                break;
        }
        
    }
    
}
