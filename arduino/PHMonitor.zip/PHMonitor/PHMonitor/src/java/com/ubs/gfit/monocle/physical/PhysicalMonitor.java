package com.ubs.gfit.monocle.physical;

import com.ubs.gfit.monocle.physical.comms.CommsController;
import com.ubs.gfit.monocle.physical.comms.CommsControllerFactory;
import com.ubs.gfit.monocle.physical.gui.InterfaceController;
import com.ubs.gfit.monocle.physical.gui.UserinterfaceControllerFactory;
import com.ubs.gfit.monocle.physical.interragator.InterrogatorFactory;

public class PhysicalMonitor
{

    public static void main(String[] args)
    {
        //Create a SerialController
        CommsController serialController = CommsControllerFactory.getCommsController("SerialController",System.getProperty("user.dir")+"/lib/");
        
        //Create a user interface controller with the specified serial controller
        InterfaceController uiController = UserinterfaceControllerFactory.getInterfaceController(serialController);
        
        
        uiController.setInterrogator(InterrogatorFactory.getInterrogator());
        uiController.initUIManager();
        uiController.createAndShowGUI();
        uiController.startInterrogator();        
    }
 
}
