package com.ubs.gfit.monocle.physical;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.lang.reflect.Field;

import org.apache.log4j.Logger;

public class Utilities
{
    private static Logger logger = Logger.getLogger(Utilities.class);
    
    public static String generateStackTrace(Throwable t) 
    { 
        ByteArrayOutputStream bOStream = new ByteArrayOutputStream(); 
        PrintStream pS = new PrintStream(bOStream); 

        t.printStackTrace(pS); 

        pS.close(); 

        return new String(bOStream.toByteArray()); 
    }
    
    public static Object prependToJavaLibraryPath(String newPath) throws NoSuchFieldException, IllegalAccessException
    {
        String currentPath = System.getProperty("java.library.path");
        logger.debug("Prepending :["+newPath+"] to java.library.path");

        // Reset the "sys_paths" field of the ClassLoader to null.
        Class<ClassLoader> clazz = ClassLoader.class;
        Field field = null;
        boolean accessible=false;
        Object original=null;
        
        try
        {
            field = clazz.getDeclaredField("sys_paths");

            accessible = field.isAccessible();
            if (!accessible)
                field.setAccessible(true);

            original = field.get(clazz);

            // Reset field to null causes the sys_path to be rebuilt when a call is made to
            // System.loadLibrary.
            field.set(clazz, null);

            // Pre-pend the new path to the java.library.path
            System.setProperty("java.library.path", newPath+File.pathSeparator+currentPath);
        }
        finally 
        {
            // Revert back the field accessibility.
            field.setAccessible(accessible);
        }

        return original;
    }

}
