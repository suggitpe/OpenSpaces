package com.ubs.gfit.monocle.physical;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.apache.log4j.Logger;

public class PropertiesController
{
    private Logger logger = Logger.getLogger(PropertiesController.class);
    private Properties props = null;
    
    public PropertiesController()
    {
        new PropertiesController("/interrogator.xml");
    }
    
    public PropertiesController(String resource)
    {
        logger.debug("Getting xml file:"+resource);
        URL propertiesURL = PhysicalMonitor.class.getResource(resource);
        logger.debug("Got URL="+propertiesURL);
        if(propertiesURL==null)
        {
            logger.error("Unable to locate properties file. Terminating");
            System.exit(-1);
        }
        props = new Properties();

        try
        {
            FileInputStream pin = new FileInputStream(propertiesURL.getFile());

            props.loadFromXML(pin);

        }
        catch(IOException e)
        {
            logger.error("IOException whilst loading properties from xml file.");
            logger.error("Exception:"+Utilities.generateStackTrace(e));
            System.exit(-1);
        }
    }
    
    public Object getPropertyForKey(String key)
    {
        if(props==null)
            return null;
        return props.get(key);
    }
}
