package com.ubs.gfit.monocle;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;

import com.ubs.gfit.monocle.physical.PropertiesController;
import com.ubs.gfit.monocle.physical.interragator.Interrogator;
import com.ubs.gfit.monocle.physical.interragator.InterrogatorThread;


public class MonocleDatabaseInterrogator implements Interrogator

{
    private Logger logger = Logger.getLogger(InterrogatorThread.class);
	private PropertiesController propertiesController;

	public MonocleDatabaseInterrogator()
	{
		this.propertiesController = new PropertiesController("/monocle-config.xml");
	}
	
	@Override
	public void setCredentials(String username, String password) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean connected()
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void connect() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
	}
	
	public RagStatus getCurrentStatus()
	{
		HttpURLConnection con;
		StringBuffer bf = new StringBuffer();
		
		propertiesController = new PropertiesController("/monocle-config.xml");
		String url = (String)propertiesController.getPropertyForKey("overall_rag_url");
		try {
			con = (HttpURLConnection) new URL(url).openConnection();
			con.setRequestMethod("GET");
			InputStream in = con.getInputStream();
			int b=0;
			
			do
			{
				b = in.read();
				if(b!=-1)
				{
					bf.append((char)b);
					//logger.debug("got:"+b);
				}
			}
			while(b!=-1);
			logger.debug("bf="+bf.toString());
			
		}
		catch (MalformedURLException e)
		{
			logger.error("Malformed URL whilst trying to retrieve monocle status");
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			logger.error("IOException whilst trying to retrieve monocle status");
			
			e.printStackTrace();
		}
		if((bf.toString()).compareToIgnoreCase("{state=\"Red\"};")==0)
		{
			return RagStatus.RED;
		}
		if((bf.toString()).compareToIgnoreCase("{state=\"Green\"};")==0)
		{
			return RagStatus.GREEN;
		}
		if((bf.toString()).compareToIgnoreCase("{state=\"Amber\"};")==0)
		{
			return RagStatus.AMBER;
		}
		
		return RagStatus.UNKNOWN;
	}

}
