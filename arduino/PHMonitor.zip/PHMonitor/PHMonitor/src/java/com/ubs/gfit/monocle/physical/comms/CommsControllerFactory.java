package com.ubs.gfit.monocle.physical.comms;

public class CommsControllerFactory
{
    public static CommsController getCommsController(String type, String path)
    {
        if(type.compareTo("SerialController")==0)
        {
            return new SerialController(path);
        }
        return null;
    }
}
