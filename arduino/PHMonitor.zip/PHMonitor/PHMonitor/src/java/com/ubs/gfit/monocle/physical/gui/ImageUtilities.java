package com.ubs.gfit.monocle.physical.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import org.apache.log4j.Logger;

import com.ubs.gfit.monocle.physical.PhysicalMonitor;
import com.ubs.gfit.monocle.physical.comms.CommsController;

public class ImageUtilities
{
    private CommsController controller;
    private Logger logger = Logger.getLogger(ImageUtilities.class);

    public ImageUtilities(CommsController controller)
    {
        this.controller = controller;
    }

    public Image applyConnectedStatusToImage(String imageSrc)
    {
        //oops
        URL imageURL = PhysicalMonitor.class.getResource(imageSrc);

        try
        {
            if (imageURL == null)
            {
                System.err.println("Resource not found: " + imageSrc);
                return null;
            }
            BufferedImage bi = ImageIO.read(imageURL);
            logger.debug("image read from:"+imageURL);
            int w = bi.getWidth(null);
            int h = bi.getHeight(null);

            logger.debug("w="+w+" h="+h);

            Graphics2D g2 = bi.createGraphics();

            //Make image lighter or darker
            //RescaleOp rop = new RescaleOp(1.1f, 20.0f, null);
            //g2.drawImage(bi, rop, 0, 0);


            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.black);
            g2.setFont(new Font("Courier", Font.PLAIN, 16));
            if(controller.connected())
            {
                g2.drawString("*", 4,13);
            }

            return bi;
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return null;
    }

    // Obtain the image URL
    public Image createImage(String path, String description)
    {
        URL imageURL = PhysicalMonitor.class.getResource(path);

        if (imageURL == null)
        {
            System.err.println("Resource not found: " + path);
            return null;
        }
        else
        {
            return (new ImageIcon(imageURL, description)).getImage();
        }
    }
}
