package com.ubs.gfit.monocle.physical.interragator;

public interface Interrogator 
{
	public enum RunState {RUNNING, RERUNNING, COMPLETE, ERROR};
	public enum RagStatus {RED, AMBER, GREEN, UNKNOWN};
	
    /**
     * Sets a username/password pair used for authentication against the target data source.
     * The password is cleartext.
     * @param username String representing the username
     * @param password String representing a password, this is a cleartext string and will be passed to 
     * the underlying data source as is.
     */
    public void setCredentials(String username, String password);
    
    /**
     * Determines whether the underlying data source is connected (or can be connected to on
     * subsequent requests for data.
     * @return boolean, true indicating a connection exists
     */
    public boolean connected();
    
    /**
     * Connect to the underlying data source using an appropriate mechanism.
     */
    public void connect();
    
    /**
     * Return the current status for this interrogator
     * @return the current statis in terms of RAG
     */
    public RagStatus getCurrentStatus();
    
    /**
     * Disconnect from the underlying data source using an appropriate mechanism.
     */
    public void disconnect();
}
