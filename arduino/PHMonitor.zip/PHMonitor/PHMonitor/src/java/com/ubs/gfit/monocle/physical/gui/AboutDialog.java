package com.ubs.gfit.monocle.physical.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComponent;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.LayoutStyle;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

/**
 * AboutDialog for Physical Monitor
 */
public class AboutDialog extends javax.swing.JDialog
{

    /**
     * 
     */
    private static final long serialVersionUID = 6796896168268595654L;

    {
        // Set Look & Feel
        try
        {
            javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private JLabel aboutText;

    private JButton okButton;

    private AbstractAction okButtonAction;

    private JLabel ubsLogo;

    private JLabel titleText;

    private JLabel primaryLogo;

    /**
     * Auto-generated main method to display this JDialog
     */
    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                JFrame frame = new JFrame();
                AboutDialog inst = new AboutDialog(frame);
                inst.setVisible(true);
            }
        });
    }

    public AboutDialog(JFrame frame)
    {
        super(frame);
        initGUI();
    }

    private void initGUI()
    {
        try
        {
            GroupLayout thisLayout = new GroupLayout((JComponent) getContentPane());
            getContentPane().setLayout(thisLayout);
            this.setTitle("About");
            this.setResizable(false);
            //this.setDefaultLookAndFeelDecorated(true);
            JDialog.setDefaultLookAndFeelDecorated(true);
            {
                aboutText = new JLabel();
                aboutText.setText("Version 0.1, Monocle Physical Monitor.");
                aboutText.setHorizontalTextPosition(SwingConstants.LEADING);
                aboutText.setHorizontalAlignment(SwingConstants.CENTER);
            }
            {
                titleText = new JLabel();
                titleText.setText("Monocle Physical Monitor");
                titleText.setFont(new java.awt.Font("Frutiger 45 Light", 1, 22));
                titleText.setHorizontalAlignment(SwingConstants.LEFT);
                titleText.setHorizontalTextPosition(SwingConstants.CENTER);
            }
            {
                okButton = new JButton();
                okButton.setText("OK");
                okButton.setAction(getOkButtonPressAction());
            }
            {
                primaryLogo = new JLabel();
                primaryLogo.setOpaque(true);
                primaryLogo.setIcon(new ImageIcon(getClass().getClassLoader().getResource(
                        "com/ubs/gfit/monocle/physical/images/rsz_monocle.png")));
            }
            thisLayout
                    .setVerticalGroup(thisLayout.createSequentialGroup().addContainerGap().addGroup(
                            thisLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(getUBSLogo(),
                                    GroupLayout.Alignment.BASELINE, 0, 38, Short.MAX_VALUE).addComponent(titleText,
                                    GroupLayout.Alignment.BASELINE, GroupLayout.PREFERRED_SIZE, 38,
                                    GroupLayout.PREFERRED_SIZE)).addPreferredGap(
                            LayoutStyle.ComponentPlacement.UNRELATED).addComponent(primaryLogo, GroupLayout.PREFERRED_SIZE,
                            118, GroupLayout.PREFERRED_SIZE).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(
                                    thisLayout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(
                                            aboutText, GroupLayout.Alignment.BASELINE, GroupLayout.PREFERRED_SIZE, 49,
                                            GroupLayout.PREFERRED_SIZE).addComponent(okButton,
                                            GroupLayout.Alignment.BASELINE, GroupLayout.PREFERRED_SIZE,
                                            GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE)).addContainerGap());
            thisLayout.setHorizontalGroup(thisLayout.createSequentialGroup().addContainerGap().addGroup(
                    thisLayout.createParallelGroup().addGroup(
                            GroupLayout.Alignment.LEADING,
                            thisLayout.createSequentialGroup().addComponent(aboutText, 0, 295, Short.MAX_VALUE)
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(okButton,
                                            GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE,
                                            GroupLayout.PREFERRED_SIZE).addGap(18)).addGroup(
                            GroupLayout.Alignment.LEADING,
                            thisLayout.createSequentialGroup().addComponent(getUBSLogo(), GroupLayout.PREFERRED_SIZE,
                                    34, GroupLayout.PREFERRED_SIZE).addPreferredGap(
                                    LayoutStyle.ComponentPlacement.UNRELATED).addComponent(titleText, 0, 296,
                                    Short.MAX_VALUE)).addGroup(
                            GroupLayout.Alignment.LEADING,
                            thisLayout.createSequentialGroup().addComponent(primaryLogo, GroupLayout.PREFERRED_SIZE, 328,
                                    GroupLayout.PREFERRED_SIZE).addGap(12))));
            thisLayout.linkSize(SwingConstants.VERTICAL, new Component[] { titleText, getUBSLogo() });
            this.setSize(356, 271);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("serial")
    private AbstractAction getOkButtonPressAction()
    {
        if (okButtonAction == null)
        {
            okButtonAction = new AbstractAction("Ok", null)
            {
                public void actionPerformed(ActionEvent evt)
                {
                    dispose();
                }
            };

        }
        return okButtonAction;
    }

    private JLabel getUBSLogo()
    {
        if (ubsLogo == null)
        {
            ubsLogo = new JLabel();
            ubsLogo.setText("\uf061");
            ubsLogo.setFont(new java.awt.Font("UBSLogo", 0, 26));
        }
        return ubsLogo;
    }
}
